python predict_$1.py -c configs/config_$1.yaml
python utils/evaluator.py -ofp ./dataset/tashkeela/test/test.txt -tfp ./dataset/tashkeela/preds/predictions_$1.txt