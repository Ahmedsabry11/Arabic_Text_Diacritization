wget -P ./dataset https://dl.fbaipublicfiles.com/fasttext/vectors-crawl/cc.ar.300.bin.gz
gunzip cc.ar.300.bin.gz