python ./utils/get_vocab.py -c configs/embed_vocab.yaml
python ./utils/embed_vocab.py -c configs/embed_vocab.yaml