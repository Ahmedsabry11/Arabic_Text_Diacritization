from pipeline_diacritizer.pipeline_diacritizer import main

main()
